# VF Analyst

Dashboard Streamlit per dati ECMO/VAD: caricamento CSV, pulizia con audit trail, regole cliniche
di allerta, modello ML, monitoraggio live (RJ45 / simulazione) ed export HL7 v2 / FHIR R4.

- Installazione su Raspberry Pi: vedi `README_RASPBERRY.md`
- Avvio su PC: `pip install -r requirements.txt` poi `streamlit run app.py`
- Variabili opzionali: `VF_DB_PATH` (file database), `VF_USB_WATCH_DIR` (cartella chiavette da monitorare)
