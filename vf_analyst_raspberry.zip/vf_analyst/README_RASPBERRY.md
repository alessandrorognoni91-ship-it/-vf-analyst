# VF Analyst su Raspberry Pi

Dashboard ECMO che parte da sola all'accensione del Raspberry, si vede sul monitor HDMI,
importa da sola i CSV da chiavetta USB e (se la macchina lo permette) riceve dati live via RJ45.

## Cosa serve
- Raspberry Pi 4 (4 GB) con alimentatore ufficiale, microSD 32 GB classe 10/A1, monitor HDMI
- Cavo RJ45 (per il live) e una chiavetta USB (per i CSV)
- Un PC per preparare la microSD

## 1. Preparare la microSD
1. Installa **Raspberry Pi Imager** e scegli **Raspberry Pi OS (64-bit) con Desktop**
   (serve il Desktop: la dashboard si apre in un browser sullo schermo; la versione "Lite" non basta).
2. Nelle impostazioni avanzate imposta nome utente, password, Wi-Fi e abilita **SSH**.
3. Scrivi la scheda, inseriscila nel Pi, collega il monitor e accendi.

## 2. Copiare il pacchetto sul Pi
Dal tuo PC (sostituisci `pi` con il tuo nome utente):
```
scp vf_analyst_raspberry.zip pi@raspberrypi.local:~
ssh pi@raspberrypi.local
sudo apt install -y unzip
unzip vf_analyst_raspberry.zip
cd vf_analyst
chmod +x install.sh uninstall.sh
```
In alternativa copia lo zip con una chiavetta ed estrailo nella cartella home.

## 3. Installare
```
./install.sh --kiosk
```
Richiede 5-10 minuti (scarica pandas, scikit-learn ecc.). Al termine vedi
`OK: VF Analyst e' attivo`. Riavvia con `sudo reboot`: dopo l'avvio del desktop la dashboard
si apre a schermo intero. Senza `--kiosk` apri a mano `http://localhost:8501` nel browser.

Opzione `--lan`: rende la dashboard visibile anche da altri PC della rete
(`http://raspberrypi.local:8501`). Non c'e' password: usala solo su una rete fidata.

## 4. Uso quotidiano
**Da chiavetta USB:** esporta il CSV dalla console, inserisci la chiavetta nel Pi, scegli
"Open CSV Mode". Entro ~5 secondi il caso compare e viene selezionato. Lo stesso file non
viene importato due volte. I dati restano salvati in `data/vf.db` anche dopo lo spegnimento.

**Live via RJ45:** scegli "Open Live Mode".
- "Simulation" funziona subito, senza macchina: serve per demo e prove.
- "VitalFlow via RJ45" richiede indirizzo IP e porta della macchina e che la macchina invii
  dati in uno dei formati supportati (HL7 ORU^R01 su MLLP, JSON o binario). Il protocollo reale
  della VitalFlow MC3 va confermato con la documentazione Medtronic.
- Con cavo diretto Pi-macchina non c'e' DHCP: assegna al Pi un IP fisso nella stessa rete
  della macchina, ad esempio (adatta nome connessione e indirizzi):
  ```
  sudo nmcli con mod "Wired connection 1" ipv4.method manual ipv4.addresses 192.168.1.10/24
  sudo nmcli con up "Wired connection 1"
  ```
  Su quella porta il Pi non avra' piu' internet: usa il Wi-Fi o un adattatore USB-Ethernet.

## 5. Comandi utili
```
sudo systemctl status vf-analyst      # stato
sudo systemctl restart vf-analyst     # riavvio
journalctl -u vf-analyst -n 50        # ultimi messaggi / errori
```
**Aggiornare:** sostituisci i file `.py` nella cartella e lancia `sudo systemctl restart vf-analyst`.
**Backup:** copia `data/vf.db`. **Rimuovere:** `./uninstall.sh` (i dati restano).

## Limiti da conoscere
- Pacchetto provato su Linux (Python 3.13) con test automatici: avvio del server, importazione
  da una finta chiavetta con `caselog_29.csv`, database su file, ricezione HL7/MLLP simulata.
  **Non e' stato provato su un Raspberry Pi reale**: l'installazione e il kiosk al boot vanno
  verificati sul tuo dispositivo.
- Strumento di ricerca/dimostrazione: non validato clinicamente, non sostituisce il monitoraggio
  standard e non va usato per decisioni sul paziente.
