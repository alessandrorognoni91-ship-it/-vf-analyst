#!/usr/bin/env bash
# VF Analyst - installazione su Raspberry Pi OS (Bookworm/Trixie, 64-bit, con Desktop)
# Uso:  ./install.sh [--kiosk] [--lan]
#   --kiosk  apre automaticamente la dashboard a schermo intero all'avvio del desktop
#   --lan    rende la dashboard raggiungibile anche da altri PC della rete (senza password!)
set -euo pipefail

KIOSK=0; ADDR="127.0.0.1"
for a in "$@"; do
  case "$a" in
    --kiosk) KIOSK=1 ;;
    --lan)   ADDR="0.0.0.0" ;;
    *) echo "Opzione sconosciuta: $a"; exit 1 ;;
  esac
done

if [[ "$EUID" -eq 0 ]]; then
  echo "Esegui lo script come utente normale (non con sudo): chiedera' la password quando serve."
  exit 1
fi

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_USER="$(id -un)"
USB_DIR="/media/${APP_USER}"
SERVICE=/etc/systemd/system/vf-analyst.service

echo "==> 1/5 Pacchetti di sistema"
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip

echo "==> 2/5 Ambiente Python (puo' richiedere 5-10 minuti sul Pi)"
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
mkdir -p "$APP_DIR/data"

echo "==> 3/5 Servizio di avvio automatico"
sudo tee "$SERVICE" > /dev/null << UNIT
[Unit]
Description=VF Analyst (dashboard ECMO)
After=network.target

[Service]
User=${APP_USER}
WorkingDirectory=${APP_DIR}
Environment=VF_DB_PATH=${APP_DIR}/data/vf.db
Environment=VF_USB_WATCH_DIR=${USB_DIR}
ExecStart=${APP_DIR}/.venv/bin/streamlit run app.py --server.port 8501 --server.address ${ADDR} --server.headless true
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now vf-analyst

echo "==> 4/5 Schermo intero all'avvio (opzionale)"
if [[ "$KIOSK" -eq 1 ]]; then
  BROWSER="$(command -v chromium-browser || command -v chromium || true)"
  if [[ -z "$BROWSER" ]]; then
    sudo apt-get install -y chromium-browser || sudo apt-get install -y chromium || true
    BROWSER="$(command -v chromium-browser || command -v chromium || true)"
  fi
  if [[ -n "$BROWSER" ]]; then
    mkdir -p "$HOME/.config/autostart"
    cat > "$HOME/.config/autostart/vf-analyst-kiosk.desktop" << DESK
[Desktop Entry]
Type=Application
Name=VF Analyst kiosk
Exec=sh -c "sleep 10 && ${BROWSER} --kiosk --noerrdialogs --disable-infobars http://localhost:8501"
DESK
    echo "    Kiosk configurato con $BROWSER"
  else
    echo "    Chromium non trovato: apri a mano http://localhost:8501 nel browser."
  fi
else
  echo "    Saltato (usa ./install.sh --kiosk per attivarlo)."
fi

echo "==> 5/5 Verifica"
sleep 6
if systemctl is-active --quiet vf-analyst; then
  echo "OK: VF Analyst e' attivo su http://localhost:8501"
  echo "Chiavette USB monitorate in: ${USB_DIR}"
else
  echo "ATTENZIONE: il servizio non e' partito. Dettagli: journalctl -u vf-analyst -n 50"
  exit 1
fi
