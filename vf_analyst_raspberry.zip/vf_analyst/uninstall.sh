#!/usr/bin/env bash
# Rimuove il servizio e l'avvio kiosk. NON cancella i dati (cartella data/).
set -euo pipefail
sudo systemctl disable --now vf-analyst 2>/dev/null || true
sudo rm -f /etc/systemd/system/vf-analyst.service
sudo systemctl daemon-reload
rm -f "$HOME/.config/autostart/vf-analyst-kiosk.desktop"
echo "Servizio rimosso. I dati restano in: $(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/data"
